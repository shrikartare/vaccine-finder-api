var API_URLS = {
  findByPincode:
    "https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict",
};

module.exports = API_URLS;
