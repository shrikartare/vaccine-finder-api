var APP_CONSTANTS = {
  userAgent:
    "Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36",
};

module.exports = APP_CONSTANTS;
